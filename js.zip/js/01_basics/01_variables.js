const accountId = 144553;
let accountEmail = "adnan@gmail.com";
var accountPassword = "12345"; // we don't use var
accountCity = "Lahore";
let accountState;
// accountId = 2; not possible and not allowed

accountEmail = "ali@gmail.com";
accountPassword = "2121212";
accountCity = "karachi";
console.log(accountId);

/*
    Prefer not to use var 
    because of the  issue in block scope and functional scope
*/

console.table([accountId, accountEmail,accountPassword,accountCity]);
console.log(accountState);
