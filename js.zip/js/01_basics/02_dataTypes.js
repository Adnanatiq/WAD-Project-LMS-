"use strict"; //treat all JS code as newer version

// alert(3+3); we are using node js not browser

console.log(3+3);
console.log("Adnan");


let name = "Adnan";
let age = 18;
let isLoggedIn = true;
let state;// undefined
let state2 = null; //also means empty

//___________________________These are premitive datatypes__________________________________________
// number => 2 to power 53
// bigint
// string => ""
// boolean => true/false
// null => stand alone value 
// undefined
// symbol => to find uniqueness 


console.log(typeof undefined); // undefined
console.log(typeof null); // object

//___________________________________________________non premitive datatypes_____________________________________
//object
// 