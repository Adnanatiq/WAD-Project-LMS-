// Primitive

// 7 types : String,Number,Boolean,null(empty),undefined, Symbol, BigInt

// defining a symbol

const id = Symbol('123');
const anotherId = Symbol('123');
//Above all the values are not same
console.log(id === anotherId);

// Reference (Non primitive)

// Array, Objects, Functions

const heros = ["spiderman", "batman", "superman"];
let obj = {
    name: "Adnan",
    age: 20
}

const myfunction = function(){
    console.log("Hello");
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// Stack(primitive), Heap(non-primitive)

let myYoutubename = "adclips.com";

let anothername = myYoutubename;
anothername = "chai aur code";
console.log(myYoutubename);
console.log(anothername);

let userOne = {
    email: "user@google.com",
    upi: "user@ybl"
}

let userTwo = userOne

userTwo.email = "hitesh@google.com";
console.log(userOne.email);
console.log(userTwo.email);