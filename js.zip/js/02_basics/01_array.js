const myArr = [1,2,3,4,5,6,7];
const myHeros = ["Spiderman", "batman"];
const myArr2 = new Array(1,2,3,4,5);
// console.log(myArr[4]);
// console.log(myArr[1]);

// Array methods

// myArr.push(8);
// myArr.push(9);
// myArr.pop();

// myArr.unshift(0);
// myArr.shift();
// console.log(myArr.includes(3));
// console.log(myArr.indexOf(3));
// console.log(myArr);

const newArr = myArr.join();

// console.log(myArr);
// console.log(newArr);
// console.log(typeof newArr);

// slice and splice

console.log("A ", myArr);
const myn1 = myArr.slice(1,3);
console.log(myn1);

console.log("B ", myArr);

/*
Difference between splice and slice
**
*/