

function sayMyName(){
    console.log("A");
    console.log("D");
    console.log("N");
    console.log("A");
    console.log("N");
}

// sayMyName();
// sayMyName();

function addTwoNumbers(number1, number2){ //parameters
    return number1 + number2;
}

const result = addTwoNumbers(3,3); //arguments

// console.log("Result: ", result);

function loginUserMessage(username = "Adnan"){
    if(username === undefined){
        console.log("Please enter a username");
        return;
    }
    return `${username} just logged in`;
}
// console.log(loginUserMessage());

function calculateCartPrice(...num1){ // rest and spread operator
    return num1;
}
// console.log(calculateCartPrice(200,400,500));

const user = {
    username: "Adnan",
    price: 199
}

function handleObject(anyObject){
    console.log(`User is ${anyObject.username} and price is ${anyObject.price}`);
}

// handleObject(user);
// handleObject({
//     username: "Ali",
//     price: 344
// })

const myNewArray = [200, 400, 100, 600];

function returnSecondValue(getArray){
    return getArray[1];
}

console.log(returnSecondValue(myNewArray));