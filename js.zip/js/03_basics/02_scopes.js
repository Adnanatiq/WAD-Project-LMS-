var c = 300;
let a = 300;
// block scope
if(true){
let a = 10;
const b = 20;
var c = 30;
// console.log(a);
}
// console.log(a); not allowed
// console.log(b); not allowed
// console.log(c);

// console.log(a);


function one(){
    const username = "Adnan";

    function two(){
        const website = "youtube";
        console.log(username);
    }
    // console.log(website); error not allowed
    two();
}

// one();

if(true){
    const username = "Adnan";
    if(username === "Adnan"){
        const website = " Youtube";
        console.log(username + website);
    }
    // console.log(website); not allowed the inside of the  function can access the outside
}

// console.log(username);

// +++++++++++++++++++++++ interesting ++++++++++++++++++++++++++

console.log(addone(5));
function addone(num){ // basic function
    return num + 1;
}

const addTwo = function(num){ // also known as experession
    return num + 2;
}



console.log(addTwo(5));