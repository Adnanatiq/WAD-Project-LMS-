const user = {
    username: "Adnan",
    price: 999,
    welcomeMessage: function(){
        console.log(`${this.username}, welcome to website`); //In current context
        console.log(this);
    }
}

// user.welcomeMessage();
// user.username = "Ali"; // context changed
// user.welcomeMessage();

// console.log(this);

// function chai(){
//     let username = "Adnan";
//     console.log(this.username);
// }
// chai();


const chai = ()=>{
    let username = "Adnan";
    console.log(this);
}

// chai();

// const addTwo = (num1,num2)=>{
//     return num1 + num2;
// }

// const addTwo =(num1, num2) => num1 + num2; //implicit return

console.log(addTwo(3,4));