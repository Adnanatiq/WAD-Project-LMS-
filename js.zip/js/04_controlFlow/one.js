// if
const isUserLoggedIn = true;
const temperature = 51;
if(isUserLoggedIn){

}
if(3!=2){

}
if(2==="2"){
    // console.log("Executed");
}
if(temperature < 50){
    // console.log("Less than 50");
}
else{
    // console.log("Temperature is greater than 50");
}

// 3!=2 negative checking the rsult will be true
// <, >, <=, >=, ==, !=, ===, !==

const score = 200;

if(score > 100){
    const power = "fly";
    // console.log(`User Power: ${power}`);
}

const balance = 1000;

// if(balance > 500) console.log("Test"); // implicit scope
// not recomended

if(balance < 500){
    // console.log("Less than 500");
}
else if(balance < 750){
    // console.log("Less than 750");
}
else if(balance < 900){
    // console.log("Less than 750");
}
else{
    // console.log("Less than 1200");
}

const userLoggedIn = true;
const debitCard = true;
const loggedInFromGoogle = false;
const loggedInFromEmail = true;

if(userLoggedIn && debitCard && 2==3){
    console.log("Allow to buy courses");
}

if(loggedInFromEmail || loggedInFromGoogle){
    console.log("user logged in.");
}