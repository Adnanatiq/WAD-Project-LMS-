
const month = 3;

switch(month){
    case 1:
        console.log("January");
        break;
    case 2:
        console.log("Feb");
        break;
    case 3:
        console.log("march");
        break;
    case 4:
        console.log("april");
        break;
    
    default:
        console.log("Wrong input");
        break;
}