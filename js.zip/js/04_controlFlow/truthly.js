const userEmail = [];

if(userEmail){
    // console.log("Got user email");
}

else{
    // console.log("Don't have user email");
}

// falsy values 
// false, 0, -0, BigInt 0n, "", null, undefined, NaN

// Truthy values 
// "0", 'false', " ", [], {}, function(){}

if(userEmail.length === 0){
    console.log("Array is empty");
}

const emptyObj = {};

if(Object.keys(emptyObj).length){
    // console.log("Object is empty");
}

// false == 0 => true
// flase == ''=>true
// 0 == '' =>true

// Nullish Coalescing Operaot (??):null undefined

let val1 = 5 ?? 10;
let val2 = null ?? 10;
let val3 = undefined ?? 15;
// console.log(val1);
// console.log(val2);
// console.log(val3);

// Terniary Operaot

// condition ? true : false 

const iceTeaPrice = 100;

iceTeaPrice <= 80 ? console.log("Less than 80") : console.log("More than 80");