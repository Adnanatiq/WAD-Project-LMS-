//for 

for(let i = 0; i <= 10; i++){
    const element = i;
    if(element == 5){
        // console.log("5 is best number");
    }
    // console.log(element);
}

for(let i=1; i<=10; i++){
    // console.log(`Outer Loop value: ${i}`)
    for(let j= 1; j<=10; j++){
        // console.log(`Innter loop value ${j} and inner loop ${i}`);
        // console.log(i + ' X ' + j + ' = ' + i*j);
    }
}

let myArray = ["flah", "batman", "superman"];
// console.log(myArray.length);
for(let index = 0; index<myArray.length; index++){
    const element = myArray[index];
    // console.log(element);
}

// break and continue

for(let i =0; i<=20; i++){

    if(i == 5){
         console.log(`Detected 5`); //loop stops wordking
        break;
    }
    console.log(`Value of i is ${i}`);
}


for(let i =0; i<=20; i++){

    if(i == 5){
         console.log(`Detected 5`); //loop stops wordking
        continue; // aik bar maaf kardo 
        // detects and continue form theri
    }
    console.log(`Value of i is ${i}`);
}