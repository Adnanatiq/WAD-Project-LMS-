// for each loop
const coding = ["js", "ruby", "java", "python", "cpp"];
//call back function has no name
// for each is used mostly in arrays
coding.forEach(function(val){
    // console.log(val);
});

coding.forEach((val) => {
    // console.log(val);
})

function printMe(item){
    console.log(item);
}

// coding.forEach(printMe);

coding.forEach( (item,index, arr)=>{
    // console.log(item,index, arr);
});

const myCoding = [
    {
        languageName: "javascript",
        languageFileName: "js"
    },
    {
        languageName: "java",
        languageFileName: "java"
    },
    {
        languageName: "C++",
        languageFileName: "cpp"
    }
];

myCoding.forEach((item)=>{
    console.log(item.languageName);
    console.log(item.languageFileName);
});