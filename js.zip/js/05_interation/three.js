// for of loops is array specific loop

// ["","",""];
// [{}, {}, {}];

const arr = [1,2,3,4,5];

for(const num of arr){
    // console.log(num);
    
}

const greetings = "Hello World!";
for(const i of greetings){
    if(i === " "){
        continue;
    }
    // console.log('Each char is: ',i);
}

// Maps
const map = new Map();
map.set('PK',"Pakistan");
map.set('USA','United States of America');
map.set('UK','United kingdom');
// map.set('UK','United kingdom'); maps are unique values. it does not dulpicate and united kingdom will dispaly only once

// console.log(map);

for(const [key,value] of map){
    // console.log(key, ":-",value);
}

const myObject = {
    'Game1': 'MFS',
    'Game2': 'Spiderman'
}

for(const [key,value] of myObject){
    // console.log(key,":-",value);// objects are not ieratable.
}