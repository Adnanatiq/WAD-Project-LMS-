# javascript and classes 

## OOP (Programming paradime) style of writing a code

## Object
- collection of propoerties and methonds
- toLowerCase

## why use OOP

## parts of OOP
Object literal

- Constructor function
- prototypes
- Classes
- Instances (new, this)


## 4 Pillars
Abstraction
Encapsulation(wrap up)
Inheritance
Polymorphism